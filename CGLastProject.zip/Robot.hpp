#pragma once
#include "GL/glew.h"
#include "GL/freeglut.h"
#include "GL/glm/glm.hpp"
#include "GL/glm/ext.hpp"
#include "GL/glm/gtc/matrix_transform.hpp"

class Robot
{
public:
	Robot();
	void draw(GLint modelTransformLocation);
	void update(float);
	void changeXpos(float deltaX) { robotXpos += deltaX; }
	void changeYpos(float deltaY) { robotYpos += deltaY; }
	float retRobotXpos() { return robotXpos; }
	~Robot();
private:
	float robotXpos;
	float robotYpos;
	float robotZpos;
	unsigned int VAO[6];
	unsigned int VBO[6];
	unsigned int VBOC[6];
	float bodyRads;
	bool isBodyUp;
	//���̶� �ٸ��� �鸮���ִ°�

	glm::mat4 transMatrix;
	GLvoid initMatrix();
};